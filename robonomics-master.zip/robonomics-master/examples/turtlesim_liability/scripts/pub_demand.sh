#!/usr/bin/env sh
rostopic pub -1 /liability/demand/send robonomics_msgs/Order "model: 'QmZZcQKjQsybsoxhg7WvyZ5BaKQFNd2uu3XifstqTWBmpr'
objective: 'QmVigAY3kQwgeZGVnArzhLJd4C9tzBnG2DpkTj7M1CGjtN'
cost: '1'"
